import ContactForm from "./modules/contact-form";

const contactForm = new ContactForm();